What we have accomplished so far (March 21, 2016)
- Discovered the algorithm for computing the recommended start time
- Planned for the layout of the application
- Discovered what tools/3rd part libraries to use
- Finalized which design patterns to use
- First deliverable requirements:
	- Use Case Diagram
	- Project Abstract
	- Wireframes